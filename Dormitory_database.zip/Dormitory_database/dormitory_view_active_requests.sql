create view Active_Requests as
select
    r.request_id,
    r.title,
    u.full_name,
    rm.room_number,
    s.name as status,
    p.name as priority,
    r.created_at
from Requests r
join Users u
    on r.user_id = u.user_id
join Rooms rm
    on r.room_id = rm.room_id
join Statuses s
    on r.status_id = s.status_id
join Priorities p
    on r.priority_id = p.priority_id
where s.name <> 'Закрыта';

select * from Active_Requests;