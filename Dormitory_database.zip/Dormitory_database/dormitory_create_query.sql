create table if not exists Roles (
role_id serial primary key,
name varchar(50) not null unique
);

create table if not exists Users (
user_id serial primary key,
role_id integer not null,
full_name varchar(100) not null,
sex char(1) not null check (sex in ('M', 'F')),
email varchar(100) unique,
phone varchar(20),
foreign key (role_id) references Roles(role_id)
);

create table if not exists Employees (
employee_id serial primary key,
user_id integer not null unique,
position varchar(50) not null,
foreign key (user_id) references Users(user_id)
);

create table if not exists Rooms (
room_id serial primary key,
room_number varchar(10) not null unique,
floor integer not null,
capacity integer not null check (capacity between 1 and 4),
gender_restriction varchar(10) not null
    check (gender_restriction in (
            'male',
            'female',
            'mixed'
        )
    )
);

create table if not exists Residence (
residence_id serial primary key,
user_id integer not null,
room_id integer not null,
move_in_date date not null,
contract_end_date date not null,
vacate_date date,
foreign key (user_id) references Users(user_id),
foreign key (room_id) references Rooms(room_id),
constraint chk_residence_dates 
	check (
		contract_end_date >= move_in_date
		and (
			vacate_date is null 
			or vacate_date >= move_in_date
		)
	)
);

create table if not exists Categories (
category_id serial primary key,
name varchar(100) not null unique
);

create table if not exists Statuses (
status_id serial primary key,
name varchar(50) not null unique
);

create table if not exists Priorities (
priority_id serial primary key,
name varchar(50) not null unique
);

create table if not exists Requests (
request_id serial primary key,
user_id integer not null,
category_id integer not null,
status_id integer not null,
priority_id integer not null,
room_id integer not null,
title varchar(200) not null,
description text,
created_at timestamp default current_timestamp,
updated_at timestamp default current_timestamp,
closed_at timestamp,
foreign key (user_id) references Users(user_id),
foreign key (room_id) references Rooms(room_id),
foreign key (category_id) references Categories(category_id),
foreign key (status_id) references Statuses(status_id),
foreign key (priority_id) references Priorities(priority_id),
constraint chk_request_dates
	check (
		closed_at is null
		or closed_at >= created_at)
);

create table if not exists Request_Employees (
request_employee_id serial primary key,
request_id integer not null,
employee_id integer not null,
assigned_at timestamp default current_timestamp,
foreign key (request_id) references Requests(request_id),
foreign key (employee_id) references Employees(employee_id),
constraint uq_request_employee unique (request_id, employee_id)
);

create table if not exists Comments (
comment_id serial primary key,
request_id integer not null,
user_id integer not null,
comment_text text not null,
created_at timestamp default current_timestamp,
updated_at timestamp default current_timestamp,
foreign key (request_id) references Requests(request_id),
foreign key (user_id) references Users(user_id)
);

create table if not exists History (
history_id serial primary key,
request_id integer not null,
changed_by_user_id integer not null,
field_name varchar(50) not null,
old_value text,
new_value text,
changed_at timestamp default current_timestamp,
foreign key (request_id) references Requests(request_id),
foreign key (changed_by_user_id) references Users(user_id)
);