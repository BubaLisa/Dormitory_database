--
-- PostgreSQL database dump
--

\restrict U9cBuXzoPfU9ECsDxuucP5VrOU4a11nXRZ9YkIWpVAQLEfhlX6NThGHq70bf5fU

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

-- Started on 2026-06-21 20:45:41

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 245 (class 1255 OID 16628)
-- Name: get_request_count_by_room(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_request_count_by_room(p_room_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    request_count integer;
begin
    select count(*)
    into request_count
    from Requests
    where room_id = p_room_id;

    return request_count;
end;
$$;


ALTER FUNCTION public.get_request_count_by_room(p_room_id integer) OWNER TO postgres;

--
-- TOC entry 244 (class 1255 OID 16624)
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    new.updated_at = current_timestamp;
    return new;
end;
$$;


ALTER FUNCTION public.update_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 234 (class 1259 OID 16498)
-- Name: priorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.priorities (
    priority_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.priorities OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 16509)
-- Name: requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requests (
    request_id integer NOT NULL,
    user_id integer NOT NULL,
    category_id integer NOT NULL,
    status_id integer NOT NULL,
    priority_id integer NOT NULL,
    room_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    closed_at timestamp without time zone,
    CONSTRAINT chk_request_dates CHECK (((closed_at IS NULL) OR (closed_at >= created_at)))
);


ALTER TABLE public.requests OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16437)
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    room_id integer NOT NULL,
    room_number character varying(10) NOT NULL,
    floor integer NOT NULL,
    capacity integer NOT NULL,
    gender_restriction character varying(10) NOT NULL,
    CONSTRAINT rooms_capacity_check CHECK (((capacity >= 1) AND (capacity <= 4))),
    CONSTRAINT rooms_gender_restriction_check CHECK (((gender_restriction)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying, 'mixed'::character varying])::text[])))
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 16487)
-- Name: statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statuses (
    status_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.statuses OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16401)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    sex character(1) NOT NULL,
    email character varying(100),
    phone character varying(20),
    CONSTRAINT users_sex_check CHECK ((sex = ANY (ARRAY['M'::bpchar, 'F'::bpchar])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 16629)
-- Name: active_requests; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.active_requests AS
 SELECT r.request_id,
    r.title,
    u.full_name,
    rm.room_number,
    s.name AS status,
    p.name AS priority,
    r.created_at
   FROM ((((public.requests r
     JOIN public.users u ON ((r.user_id = u.user_id)))
     JOIN public.rooms rm ON ((r.room_id = rm.room_id)))
     JOIN public.statuses s ON ((r.status_id = s.status_id)))
     JOIN public.priorities p ON ((r.priority_id = p.priority_id)))
  WHERE ((s.name)::text <> 'Закрыта'::text);


ALTER VIEW public.active_requests OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16476)
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    category_id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16475)
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_category_id_seq OWNER TO postgres;

--
-- TOC entry 5181 (class 0 OID 0)
-- Dependencies: 229
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_category_id_seq OWNED BY public.categories.category_id;


--
-- TOC entry 240 (class 1259 OID 16576)
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    comment_id integer NOT NULL,
    request_id integer NOT NULL,
    user_id integer NOT NULL,
    comment_text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 16575)
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comments_comment_id_seq OWNER TO postgres;

--
-- TOC entry 5184 (class 0 OID 0)
-- Dependencies: 239
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- TOC entry 224 (class 1259 OID 16420)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    user_id integer NOT NULL,
    "position" character varying(50) NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16419)
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employee_id_seq OWNER TO postgres;

--
-- TOC entry 5187 (class 0 OID 0)
-- Dependencies: 223
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- TOC entry 242 (class 1259 OID 16601)
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    history_id integer NOT NULL,
    request_id integer NOT NULL,
    changed_by_user_id integer NOT NULL,
    field_name character varying(50) NOT NULL,
    old_value text,
    new_value text,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.history OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 16600)
-- Name: history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.history_history_id_seq OWNER TO postgres;

--
-- TOC entry 5190 (class 0 OID 0)
-- Dependencies: 241
-- Name: history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_history_id_seq OWNED BY public.history.history_id;


--
-- TOC entry 233 (class 1259 OID 16497)
-- Name: priorities_priority_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.priorities_priority_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.priorities_priority_id_seq OWNER TO postgres;

--
-- TOC entry 5192 (class 0 OID 0)
-- Dependencies: 233
-- Name: priorities_priority_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.priorities_priority_id_seq OWNED BY public.priorities.priority_id;


--
-- TOC entry 238 (class 1259 OID 16553)
-- Name: request_employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request_employees (
    request_employee_id integer NOT NULL,
    request_id integer NOT NULL,
    employee_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.request_employees OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 16552)
-- Name: request_employees_request_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.request_employees_request_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_employees_request_employee_id_seq OWNER TO postgres;

--
-- TOC entry 5195 (class 0 OID 0)
-- Dependencies: 237
-- Name: request_employees_request_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.request_employees_request_employee_id_seq OWNED BY public.request_employees.request_employee_id;


--
-- TOC entry 235 (class 1259 OID 16508)
-- Name: requests_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.requests_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requests_request_id_seq OWNER TO postgres;

--
-- TOC entry 5197 (class 0 OID 0)
-- Dependencies: 235
-- Name: requests_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.requests_request_id_seq OWNED BY public.requests.request_id;


--
-- TOC entry 228 (class 1259 OID 16453)
-- Name: residence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.residence (
    residence_id integer NOT NULL,
    user_id integer NOT NULL,
    room_id integer NOT NULL,
    move_in_date date NOT NULL,
    contract_end_date date NOT NULL,
    vacate_date date,
    CONSTRAINT chk_residence_dates CHECK (((contract_end_date >= move_in_date) AND ((vacate_date IS NULL) OR (vacate_date >= move_in_date))))
);


ALTER TABLE public.residence OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16452)
-- Name: residence_residence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.residence_residence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.residence_residence_id_seq OWNER TO postgres;

--
-- TOC entry 5200 (class 0 OID 0)
-- Dependencies: 227
-- Name: residence_residence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.residence_residence_id_seq OWNED BY public.residence.residence_id;


--
-- TOC entry 220 (class 1259 OID 16390)
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16389)
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_role_id_seq OWNER TO postgres;

--
-- TOC entry 5203 (class 0 OID 0)
-- Dependencies: 219
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- TOC entry 225 (class 1259 OID 16436)
-- Name: rooms_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_room_id_seq OWNER TO postgres;

--
-- TOC entry 5205 (class 0 OID 0)
-- Dependencies: 225
-- Name: rooms_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_room_id_seq OWNED BY public.rooms.room_id;


--
-- TOC entry 231 (class 1259 OID 16486)
-- Name: statuses_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.statuses_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.statuses_status_id_seq OWNER TO postgres;

--
-- TOC entry 5207 (class 0 OID 0)
-- Dependencies: 231
-- Name: statuses_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.statuses_status_id_seq OWNED BY public.statuses.status_id;


--
-- TOC entry 221 (class 1259 OID 16400)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- TOC entry 5209 (class 0 OID 0)
-- Dependencies: 221
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 4922 (class 2604 OID 16479)
-- Name: categories category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN category_id SET DEFAULT nextval('public.categories_category_id_seq'::regclass);


--
-- TOC entry 4930 (class 2604 OID 16579)
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- TOC entry 4919 (class 2604 OID 16423)
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- TOC entry 4933 (class 2604 OID 16604)
-- Name: history history_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history ALTER COLUMN history_id SET DEFAULT nextval('public.history_history_id_seq'::regclass);


--
-- TOC entry 4924 (class 2604 OID 16501)
-- Name: priorities priority_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities ALTER COLUMN priority_id SET DEFAULT nextval('public.priorities_priority_id_seq'::regclass);


--
-- TOC entry 4928 (class 2604 OID 16556)
-- Name: request_employees request_employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_employees ALTER COLUMN request_employee_id SET DEFAULT nextval('public.request_employees_request_employee_id_seq'::regclass);


--
-- TOC entry 4925 (class 2604 OID 16512)
-- Name: requests request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests ALTER COLUMN request_id SET DEFAULT nextval('public.requests_request_id_seq'::regclass);


--
-- TOC entry 4921 (class 2604 OID 16456)
-- Name: residence residence_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residence ALTER COLUMN residence_id SET DEFAULT nextval('public.residence_residence_id_seq'::regclass);


--
-- TOC entry 4917 (class 2604 OID 16393)
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- TOC entry 4920 (class 2604 OID 16440)
-- Name: rooms room_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN room_id SET DEFAULT nextval('public.rooms_room_id_seq'::regclass);


--
-- TOC entry 4923 (class 2604 OID 16490)
-- Name: statuses status_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses ALTER COLUMN status_id SET DEFAULT nextval('public.statuses_status_id_seq'::regclass);


--
-- TOC entry 4918 (class 2604 OID 16404)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 5156 (class 0 OID 16476)
-- Dependencies: 230
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (category_id, name) FROM stdin;
1	Электрика
2	Сантехника
3	Мебель
4	Уборка
5	Интернет
\.


--
-- TOC entry 5166 (class 0 OID 16576)
-- Dependencies: 240
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (comment_id, request_id, user_id, comment_text, created_at, updated_at) FROM stdin;
1	1	1	Проблема появилась вчера	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
2	1	23	Электрик назначен	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
3	2	2	Течь усиливается	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
4	2	22	Проверю сегодня	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
5	3	3	Стул полностью сломан	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
6	3	21	Заказана замена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
7	4	4	Коридор убран	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
8	4	25	Работы завершены	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
9	5	5	Интернет всё ещё медленный	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
10	5	24	Проблема передана провайдеру	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
11	6	6	Свет отключается вечером	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
12	6	23	Проводка будет проверена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
13	7	7	Раковина полностью забита	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
14	7	22	Запланирован ремонт	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
15	8	8	Кровать опасна для использования	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
16	8	21	Кровать заменена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
17	9	9	Кухня загрязнена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
18	9	25	Уборка выполнена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
19	10	10	Проблема возникает ночью	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
20	10	24	Проверяется оборудование	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
21	11	11	Лампа не работает	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
22	11	23	Лампа заменена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
23	12	12	Протечка усилилась	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
24	12	22	Приеду после обеда	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
25	13	13	Шкаф перекосился	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
26	13	21	Требуется замена петель	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
27	14	14	Этаж убран	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
28	14	25	Заявка закрыта	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
29	15	15	Интернет отсутствует	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
30	15	24	Ведутся работы	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
31	16	16	Выключатель искрит	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
32	16	23	Осмотр запланирован	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
33	17	17	Душ протекает неделю	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
34	17	22	Смеситель заменён	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
35	18	18	Стол повреждён	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
36	18	21	Стол заменён	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
37	19	19	В душевой грязно	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
38	19	25	Уборка завершена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
39	20	20	Проблема повторяется	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
40	20	24	Проверяется роутер	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
41	21	1	Есть запах гари	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
42	21	23	Питание отключено	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
43	22	2	Засор сильный	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
44	22	22	Засор устранён	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
45	23	3	Полка отвалилась	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
46	23	21	Закуплены материалы	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
47	24	4	Мусор вывезен	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
48	24	25	Работы выполнены	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
49	25	5	Сигнал слабый вечером	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
50	25	24	Проверяется сеть	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
51	26	6	Свет не включается	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
52	26	23	Неисправность устранена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
53	27	7	Батарея протекает	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
54	27	22	Требуется замена клапана	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
55	28	8	Ящик заклинило	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
56	28	21	Ящик отремонтирован	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
57	29	9	Лестница загрязнена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
58	29	25	Уборка выполнена	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
59	30	10	Высокий пинг вечером	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
60	30	24	Проблема анализируется	2026-06-20 14:29:40.588038	2026-06-20 14:29:40.588038
\.


--
-- TOC entry 5150 (class 0 OID 16420)
-- Dependencies: 224
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, user_id, "position") FROM stdin;
1	21	Мастер
2	22	Сантехник
3	23	Электрик
4	24	Комендант
5	25	Вахтёр
\.


--
-- TOC entry 5168 (class 0 OID 16601)
-- Dependencies: 242
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (history_id, request_id, changed_by_user_id, field_name, old_value, new_value, changed_at) FROM stdin;
1	1	23	status	Новая	В работе	2026-06-20 14:29:40.588038
2	2	22	status	Новая	В работе	2026-06-20 14:29:40.588038
3	3	21	status	В работе	Выполнена	2026-06-20 14:29:40.588038
4	4	25	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
5	5	24	status	Новая	Ожидает	2026-06-20 14:29:40.588038
6	6	23	status	Новая	В работе	2026-06-20 14:29:40.588038
7	7	22	status	Новая	В работе	2026-06-20 14:29:40.588038
8	8	21	status	В работе	Выполнена	2026-06-20 14:29:40.588038
9	9	25	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
10	10	24	status	Новая	В работе	2026-06-20 14:29:40.588038
11	11	23	status	В работе	Выполнена	2026-06-20 14:29:40.588038
12	12	22	status	Новая	В работе	2026-06-20 14:29:40.588038
13	13	21	status	Новая	В работе	2026-06-20 14:29:40.588038
14	14	25	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
15	15	24	status	Новая	В работе	2026-06-20 14:29:40.588038
16	16	23	status	Новая	В работе	2026-06-20 14:29:40.588038
17	17	22	status	В работе	Выполнена	2026-06-20 14:29:40.588038
18	18	21	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
19	19	25	status	Новая	В работе	2026-06-20 14:29:40.588038
20	20	24	status	Новая	Ожидает	2026-06-20 14:29:40.588038
21	21	23	priority	Высокий	Критический	2026-06-20 14:29:40.588038
22	22	22	status	В работе	Выполнена	2026-06-20 14:29:40.588038
23	23	21	status	Новая	В работе	2026-06-20 14:29:40.588038
24	24	25	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
25	25	24	status	Новая	В работе	2026-06-20 14:29:40.588038
26	26	23	status	В работе	Выполнена	2026-06-20 14:29:40.588038
27	27	22	status	Новая	В работе	2026-06-20 14:29:40.588038
28	28	21	status	Новая	В работе	2026-06-20 14:29:40.588038
29	29	25	status	Выполнена	Закрыта	2026-06-20 14:29:40.588038
30	30	24	status	Новая	Ожидает	2026-06-20 14:29:40.588038
31	1	23	priority	Средний	Высокий	2026-06-20 14:29:40.588038
32	2	22	priority	Высокий	Срочный	2026-06-20 14:29:40.588038
33	5	24	status	В работе	Ожидает	2026-06-20 14:29:40.588038
34	10	24	priority	Средний	Высокий	2026-06-20 14:29:40.588038
35	15	24	status	В работе	Ожидает	2026-06-20 14:29:40.588038
36	20	24	priority	Высокий	Срочный	2026-06-20 14:29:40.588038
37	25	24	priority	Средний	Высокий	2026-06-20 14:29:40.588038
38	27	22	priority	Высокий	Критический	2026-06-20 14:29:40.588038
39	28	21	status	Новая	В работе	2026-06-20 14:29:40.588038
40	30	24	status	Новая	Ожидает	2026-06-20 14:29:40.588038
\.


--
-- TOC entry 5160 (class 0 OID 16498)
-- Dependencies: 234
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.priorities (priority_id, name) FROM stdin;
1	Низкий
2	Средний
3	Высокий
4	Срочный
5	Критический
\.


--
-- TOC entry 5164 (class 0 OID 16553)
-- Dependencies: 238
-- Data for Name: request_employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request_employees (request_employee_id, request_id, employee_id, assigned_at) FROM stdin;
1	1	3	2026-06-20 14:29:40.588038
2	2	2	2026-06-20 14:29:40.588038
3	3	1	2026-06-20 14:29:40.588038
4	4	5	2026-06-20 14:29:40.588038
5	5	4	2026-06-20 14:29:40.588038
6	6	3	2026-06-20 14:29:40.588038
7	7	2	2026-06-20 14:29:40.588038
8	8	1	2026-06-20 14:29:40.588038
9	9	5	2026-06-20 14:29:40.588038
10	10	4	2026-06-20 14:29:40.588038
11	11	3	2026-06-20 14:29:40.588038
12	12	2	2026-06-20 14:29:40.588038
13	13	1	2026-06-20 14:29:40.588038
14	14	5	2026-06-20 14:29:40.588038
15	15	4	2026-06-20 14:29:40.588038
16	16	3	2026-06-20 14:29:40.588038
17	17	2	2026-06-20 14:29:40.588038
18	18	1	2026-06-20 14:29:40.588038
19	19	5	2026-06-20 14:29:40.588038
20	20	4	2026-06-20 14:29:40.588038
21	21	3	2026-06-20 14:29:40.588038
22	22	2	2026-06-20 14:29:40.588038
23	23	1	2026-06-20 14:29:40.588038
24	24	5	2026-06-20 14:29:40.588038
25	25	4	2026-06-20 14:29:40.588038
26	26	3	2026-06-20 14:29:40.588038
27	27	2	2026-06-20 14:29:40.588038
28	28	1	2026-06-20 14:29:40.588038
29	29	5	2026-06-20 14:29:40.588038
30	30	4	2026-06-20 14:29:40.588038
\.


--
-- TOC entry 5162 (class 0 OID 16509)
-- Dependencies: 236
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requests (request_id, user_id, category_id, status_id, priority_id, room_id, title, description, created_at, updated_at, closed_at) FROM stdin;
1	1	1	1	3	1	Не работает розетка	Розетка возле стола искрит	2026-01-10 00:00:00	2026-01-10 00:00:00	\N
2	2	2	2	4	1	Течёт кран	Капает вода в ванной	2026-01-11 00:00:00	2026-01-12 00:00:00	\N
3	3	3	4	2	2	Сломан стул	Нужно заменить стул	2026-01-05 00:00:00	2026-01-07 00:00:00	2026-01-07 00:00:00
4	4	4	5	1	2	Грязный коридор	Требуется уборка	2026-01-03 00:00:00	2026-01-04 00:00:00	2026-01-04 00:00:00
5	5	5	3	2	3	Медленный интернет	Плохая скорость соединения	2026-01-15 00:00:00	2026-01-16 00:00:00	\N
6	6	1	2	5	3	Выключается свет	Проблемы с проводкой	2026-01-12 00:00:00	2026-01-13 00:00:00	\N
7	7	2	1	4	3	Засорилась раковина	Вода не уходит	2026-01-16 00:00:00	2026-01-16 00:00:00	\N
8	8	3	4	2	4	Сломана кровать	Трещина в каркасе	2026-01-01 00:00:00	2026-01-05 00:00:00	2026-01-05 00:00:00
9	9	4	5	1	4	Уборка кухни	Нужна генеральная уборка	2026-01-02 00:00:00	2026-01-03 00:00:00	2026-01-03 00:00:00
10	10	5	2	3	4	Пропадает Wi-Fi	Периодически исчезает сигнал	2026-01-17 00:00:00	2026-01-18 00:00:00	\N
11	11	1	4	2	5	Перегорела лампа	Не работает освещение	2026-01-08 00:00:00	2026-01-09 00:00:00	2026-01-09 00:00:00
12	12	2	2	4	5	Протечка трубы	Вода под раковиной	2026-01-20 00:00:00	2026-01-21 00:00:00	\N
13	13	3	1	2	6	Сломан шкаф	Не закрываются двери	2026-01-18 00:00:00	2026-01-18 00:00:00	\N
14	14	4	5	1	6	Мусор на этаже	Требуется уборка	2026-01-06 00:00:00	2026-01-07 00:00:00	2026-01-07 00:00:00
15	15	5	2	3	7	Нет доступа к интернету	Ошибка авторизации	2026-01-19 00:00:00	2026-01-20 00:00:00	\N
16	16	1	1	3	7	Не включается свет	Проблема с выключателем	2026-01-21 00:00:00	2026-01-21 00:00:00	\N
17	17	2	4	2	7	Течёт душ	Подтекает смеситель	2026-01-07 00:00:00	2026-01-10 00:00:00	2026-01-10 00:00:00
18	18	3	5	1	8	Повреждён стол	Сломана ножка	2026-01-04 00:00:00	2026-01-05 00:00:00	2026-01-05 00:00:00
19	19	4	2	2	8	Уборка душевой	Требуется уборка помещения	2026-01-22 00:00:00	2026-01-23 00:00:00	\N
20	20	5	3	4	8	Нестабильный интернет	Частые обрывы соединения	2026-01-22 00:00:00	2026-01-23 00:00:00	\N
21	1	1	2	5	1	Искрит удлинитель	Опасность короткого замыкания	2026-02-01 00:00:00	2026-02-02 00:00:00	\N
22	2	2	4	2	1	Засор в душе	Вода плохо уходит	2026-02-02 00:00:00	2026-02-04 00:00:00	2026-02-04 00:00:00
23	3	3	1	2	2	Сломана полка	Нужно заменить крепление	2026-02-03 00:00:00	2026-02-03 00:00:00	\N
24	4	4	5	1	2	Мусор возле входа	Требуется уборка территории	2026-02-04 00:00:00	2026-02-05 00:00:00	2026-02-05 00:00:00
25	5	5	2	3	3	Слабый сигнал Wi-Fi	Плохое покрытие сети	2026-02-05 00:00:00	2026-02-06 00:00:00	\N
26	6	1	4	2	3	Не работает выключатель	Не включается свет	2026-02-06 00:00:00	2026-02-07 00:00:00	2026-02-07 00:00:00
27	7	2	2	4	3	Протекает батарея	Вода на полу	2026-02-07 00:00:00	2026-02-08 00:00:00	\N
28	8	3	1	2	4	Сломан ящик стола	Не выдвигается	2026-02-08 00:00:00	2026-02-08 00:00:00	\N
29	9	4	5	1	4	Уборка лестницы	Скопилась грязь	2026-02-09 00:00:00	2026-02-10 00:00:00	2026-02-10 00:00:00
30	10	5	3	3	4	Интернет работает медленно	Высокий пинг	2026-02-10 00:00:00	2026-02-11 00:00:00	\N
\.


--
-- TOC entry 5154 (class 0 OID 16453)
-- Dependencies: 228
-- Data for Name: residence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.residence (residence_id, user_id, room_id, move_in_date, contract_end_date, vacate_date) FROM stdin;
1	1	1	2025-09-01	2026-06-30	\N
2	2	1	2025-09-01	2026-06-30	\N
3	3	2	2025-09-01	2026-06-30	\N
4	4	2	2025-09-01	2026-06-30	\N
5	5	3	2025-09-01	2026-06-30	\N
6	6	3	2025-09-01	2026-06-30	\N
7	7	3	2025-09-01	2026-06-30	\N
8	11	5	2025-09-01	2026-06-30	\N
9	12	5	2025-09-01	2026-06-30	\N
10	13	6	2025-09-01	2026-06-30	\N
11	14	6	2025-09-01	2026-06-30	\N
12	15	7	2025-09-01	2026-06-30	\N
13	16	7	2025-09-01	2026-06-30	\N
14	17	7	2025-09-01	2026-06-30	\N
15	18	8	2025-09-01	2026-06-30	\N
\.


--
-- TOC entry 5146 (class 0 OID 16390)
-- Dependencies: 220
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, name) FROM stdin;
1	Студент
2	Сотрудник
3	Администратор
\.


--
-- TOC entry 5152 (class 0 OID 16437)
-- Dependencies: 226
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (room_id, room_number, floor, capacity, gender_restriction) FROM stdin;
1	101	1	2	male
2	102	1	2	male
3	103	1	3	male
4	104	1	4	mixed
5	201	2	2	female
6	202	2	2	female
7	203	2	3	female
8	204	2	4	mixed
9	301	3	2	male
10	302	3	2	female
\.


--
-- TOC entry 5158 (class 0 OID 16487)
-- Dependencies: 232
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statuses (status_id, name) FROM stdin;
1	Новая
2	В работе
3	Ожидает
4	Выполнена
5	Закрыта
\.


--
-- TOC entry 5148 (class 0 OID 16401)
-- Dependencies: 222
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, role_id, full_name, sex, email, phone) FROM stdin;
1	1	Иван Иванов	M	ivanov@mail.ru	+79990000001
2	1	Пётр Петров	M	petrov@mail.ru	+79990000002
3	1	Сергей Сергеев	M	sergeev@mail.ru	+79990000003
4	1	Алексей Алексеев	M	alekseev@mail.ru	+79990000004
5	1	Максим Максимов	M	maksimov@mail.ru	+79990000005
6	1	Дмитрий Дмитриев	M	dmitriev@mail.ru	+79990000006
7	1	Егор Егоров	M	egorov@mail.ru	+79990000007
8	1	Никита Никитин	M	nikitin@mail.ru	+79990000008
9	1	Артём Артёмов	M	artemov@mail.ru	+79990000009
10	1	Владимир Владимиров	M	vladimirov@mail.ru	+79990000010
11	1	Анна Антонова	F	antonova@mail.ru	+79990000011
12	1	Мария Маркова	F	markova@mail.ru	+79990000012
13	1	Елена Егорова	F	elena@mail.ru	+79990000013
14	1	Ольга Орлова	F	orlova@mail.ru	+79990000014
15	1	Наталья Новикова	F	novikova@mail.ru	+79990000015
16	1	Светлана Смирнова	F	smirnova@mail.ru	+79990000016
17	1	Татьяна Титова	F	titova@mail.ru	+79990000017
18	1	Виктория Власова	F	vlasova@mail.ru	+79990000018
19	1	Алина Андреева	F	andreeva@mail.ru	+79990000019
20	1	Дарья Денисова	F	denisova@mail.ru	+79990000020
21	2	Василий Мастер	M	master1@mail.ru	+79990000021
22	2	Павел Сантехник	M	master2@mail.ru	+79990000022
23	2	Олег Электрик	M	master3@mail.ru	+79990000023
24	2	Ирина Комендант	F	commandant@mail.ru	+79990000024
25	2	Галина Вахтёр	F	guard@mail.ru	+79990000025
26	3	Павел Дуров	M	admin@mail.ru	+79990000026
\.


--
-- TOC entry 5211 (class 0 OID 0)
-- Dependencies: 229
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 5, true);


--
-- TOC entry 5212 (class 0 OID 0)
-- Dependencies: 239
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_comment_id_seq', 60, true);


--
-- TOC entry 5213 (class 0 OID 0)
-- Dependencies: 223
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 5, true);


--
-- TOC entry 5214 (class 0 OID 0)
-- Dependencies: 241
-- Name: history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_history_id_seq', 40, true);


--
-- TOC entry 5215 (class 0 OID 0)
-- Dependencies: 233
-- Name: priorities_priority_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.priorities_priority_id_seq', 5, true);


--
-- TOC entry 5216 (class 0 OID 0)
-- Dependencies: 237
-- Name: request_employees_request_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.request_employees_request_employee_id_seq', 30, true);


--
-- TOC entry 5217 (class 0 OID 0)
-- Dependencies: 235
-- Name: requests_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requests_request_id_seq', 30, true);


--
-- TOC entry 5218 (class 0 OID 0)
-- Dependencies: 227
-- Name: residence_residence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.residence_residence_id_seq', 15, true);


--
-- TOC entry 5219 (class 0 OID 0)
-- Dependencies: 219
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 3, true);


--
-- TOC entry 5220 (class 0 OID 0)
-- Dependencies: 225
-- Name: rooms_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_room_id_seq', 10, true);


--
-- TOC entry 5221 (class 0 OID 0)
-- Dependencies: 231
-- Name: statuses_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.statuses_status_id_seq', 5, true);


--
-- TOC entry 5222 (class 0 OID 0)
-- Dependencies: 221
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 26, true);


--
-- TOC entry 4959 (class 2606 OID 16485)
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- TOC entry 4961 (class 2606 OID 16483)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- TOC entry 4977 (class 2606 OID 16589)
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- TOC entry 4949 (class 2606 OID 16428)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 4951 (class 2606 OID 16430)
-- Name: employees employees_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_key UNIQUE (user_id);


--
-- TOC entry 4979 (class 2606 OID 16613)
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (history_id);


--
-- TOC entry 4967 (class 2606 OID 16507)
-- Name: priorities priorities_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_name_key UNIQUE (name);


--
-- TOC entry 4969 (class 2606 OID 16505)
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (priority_id);


--
-- TOC entry 4973 (class 2606 OID 16562)
-- Name: request_employees request_employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_employees
    ADD CONSTRAINT request_employees_pkey PRIMARY KEY (request_employee_id);


--
-- TOC entry 4971 (class 2606 OID 16526)
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (request_id);


--
-- TOC entry 4957 (class 2606 OID 16464)
-- Name: residence residence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residence
    ADD CONSTRAINT residence_pkey PRIMARY KEY (residence_id);


--
-- TOC entry 4941 (class 2606 OID 16399)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 4943 (class 2606 OID 16397)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- TOC entry 4953 (class 2606 OID 16449)
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (room_id);


--
-- TOC entry 4955 (class 2606 OID 16451)
-- Name: rooms rooms_room_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_room_number_key UNIQUE (room_number);


--
-- TOC entry 4963 (class 2606 OID 16496)
-- Name: statuses statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_name_key UNIQUE (name);


--
-- TOC entry 4965 (class 2606 OID 16494)
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (status_id);


--
-- TOC entry 4975 (class 2606 OID 16564)
-- Name: request_employees uq_request_employee; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_employees
    ADD CONSTRAINT uq_request_employee UNIQUE (request_id, employee_id);


--
-- TOC entry 4945 (class 2606 OID 16413)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4947 (class 2606 OID 16411)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4996 (class 2620 OID 16626)
-- Name: comments trg_comments_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_comments_updated_at BEFORE UPDATE ON public.comments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- TOC entry 4995 (class 2620 OID 16625)
-- Name: requests trg_requests_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_requests_updated_at BEFORE UPDATE ON public.requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- TOC entry 4991 (class 2606 OID 16590)
-- Name: comments comments_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(request_id);


--
-- TOC entry 4992 (class 2606 OID 16595)
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- TOC entry 4981 (class 2606 OID 16431)
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- TOC entry 4993 (class 2606 OID 16619)
-- Name: history history_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(user_id);


--
-- TOC entry 4994 (class 2606 OID 16614)
-- Name: history history_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(request_id);


--
-- TOC entry 4989 (class 2606 OID 16570)
-- Name: request_employees request_employees_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_employees
    ADD CONSTRAINT request_employees_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id);


--
-- TOC entry 4990 (class 2606 OID 16565)
-- Name: request_employees request_employees_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request_employees
    ADD CONSTRAINT request_employees_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.requests(request_id);


--
-- TOC entry 4984 (class 2606 OID 16537)
-- Name: requests requests_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- TOC entry 4985 (class 2606 OID 16547)
-- Name: requests requests_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.priorities(priority_id);


--
-- TOC entry 4986 (class 2606 OID 16532)
-- Name: requests requests_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id);


--
-- TOC entry 4987 (class 2606 OID 16542)
-- Name: requests requests_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.statuses(status_id);


--
-- TOC entry 4988 (class 2606 OID 16527)
-- Name: requests requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- TOC entry 4982 (class 2606 OID 16470)
-- Name: residence residence_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residence
    ADD CONSTRAINT residence_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(room_id);


--
-- TOC entry 4983 (class 2606 OID 16465)
-- Name: residence residence_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.residence
    ADD CONSTRAINT residence_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- TOC entry 4980 (class 2606 OID 16414)
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id);


--
-- TOC entry 5174 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE priorities; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.priorities TO dorm_employee;
GRANT ALL ON TABLE public.priorities TO dorm_admin;


--
-- TOC entry 5175 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.requests TO dorm_user;
GRANT SELECT,UPDATE ON TABLE public.requests TO dorm_employee;
GRANT ALL ON TABLE public.requests TO dorm_admin;


--
-- TOC entry 5176 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE rooms; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.rooms TO dorm_employee;
GRANT ALL ON TABLE public.rooms TO dorm_admin;


--
-- TOC entry 5177 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE statuses; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.statuses TO dorm_employee;
GRANT ALL ON TABLE public.statuses TO dorm_admin;


--
-- TOC entry 5178 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.users TO dorm_employee;
GRANT ALL ON TABLE public.users TO dorm_admin;


--
-- TOC entry 5179 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE active_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.active_requests TO dorm_employee;
GRANT ALL ON TABLE public.active_requests TO dorm_admin;


--
-- TOC entry 5180 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.categories TO dorm_employee;
GRANT ALL ON TABLE public.categories TO dorm_admin;


--
-- TOC entry 5182 (class 0 OID 0)
-- Dependencies: 229
-- Name: SEQUENCE categories_category_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.categories_category_id_seq TO dorm_admin;


--
-- TOC entry 5183 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE comments; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.comments TO dorm_user;
GRANT SELECT,INSERT ON TABLE public.comments TO dorm_employee;
GRANT ALL ON TABLE public.comments TO dorm_admin;


--
-- TOC entry 5185 (class 0 OID 0)
-- Dependencies: 239
-- Name: SEQUENCE comments_comment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.comments_comment_id_seq TO dorm_admin;


--
-- TOC entry 5186 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.employees TO dorm_employee;
GRANT ALL ON TABLE public.employees TO dorm_admin;


--
-- TOC entry 5188 (class 0 OID 0)
-- Dependencies: 223
-- Name: SEQUENCE employees_employee_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.employees_employee_id_seq TO dorm_admin;


--
-- TOC entry 5189 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE history; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.history TO dorm_employee;
GRANT ALL ON TABLE public.history TO dorm_admin;


--
-- TOC entry 5191 (class 0 OID 0)
-- Dependencies: 241
-- Name: SEQUENCE history_history_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.history_history_id_seq TO dorm_admin;


--
-- TOC entry 5193 (class 0 OID 0)
-- Dependencies: 233
-- Name: SEQUENCE priorities_priority_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.priorities_priority_id_seq TO dorm_admin;


--
-- TOC entry 5194 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE request_employees; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.request_employees TO dorm_employee;
GRANT ALL ON TABLE public.request_employees TO dorm_admin;


--
-- TOC entry 5196 (class 0 OID 0)
-- Dependencies: 237
-- Name: SEQUENCE request_employees_request_employee_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.request_employees_request_employee_id_seq TO dorm_admin;


--
-- TOC entry 5198 (class 0 OID 0)
-- Dependencies: 235
-- Name: SEQUENCE requests_request_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.requests_request_id_seq TO dorm_admin;


--
-- TOC entry 5199 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE residence; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.residence TO dorm_employee;
GRANT ALL ON TABLE public.residence TO dorm_admin;


--
-- TOC entry 5201 (class 0 OID 0)
-- Dependencies: 227
-- Name: SEQUENCE residence_residence_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.residence_residence_id_seq TO dorm_admin;


--
-- TOC entry 5202 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.roles TO dorm_employee;
GRANT ALL ON TABLE public.roles TO dorm_admin;


--
-- TOC entry 5204 (class 0 OID 0)
-- Dependencies: 219
-- Name: SEQUENCE roles_role_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.roles_role_id_seq TO dorm_admin;


--
-- TOC entry 5206 (class 0 OID 0)
-- Dependencies: 225
-- Name: SEQUENCE rooms_room_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.rooms_room_id_seq TO dorm_admin;


--
-- TOC entry 5208 (class 0 OID 0)
-- Dependencies: 231
-- Name: SEQUENCE statuses_status_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.statuses_status_id_seq TO dorm_admin;


--
-- TOC entry 5210 (class 0 OID 0)
-- Dependencies: 221
-- Name: SEQUENCE users_user_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.users_user_id_seq TO dorm_admin;


-- Completed on 2026-06-21 20:45:41

--
-- PostgreSQL database dump complete
--

\unrestrict U9cBuXzoPfU9ECsDxuucP5VrOU4a11nXRZ9YkIWpVAQLEfhlX6NThGHq70bf5fU

