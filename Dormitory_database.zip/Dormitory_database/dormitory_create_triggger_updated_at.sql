create or replace function update_updated_at()
returns trigger
as $$
begin
    new.updated_at = current_timestamp;
    return new;
end;
$$ language plpgsql;

create trigger trg_requests_updated_at
before update on Requests
for each row
execute function update_updated_at();

create trigger trg_comments_updated_at
before update on Comments
for each row
execute function update_updated_at();