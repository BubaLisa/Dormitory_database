create or replace function get_request_count_by_room(
    p_room_id integer
)
returns integer
as $$
declare
    request_count integer;
begin
    select count(*)
    into request_count
    from Requests
    where room_id = p_room_id;

    return request_count;
end;
$$ language plpgsql;

select get_request_count_by_room(1)