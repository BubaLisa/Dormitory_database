--Количество заявок по статусам
select
    s.name as status_name,
    count(r.request_id) as request_count
from Requests r
join Statuses s
    on r.status_id = s.status_id
group by s.name;

--Динамика заявок по месяцам
select
    date_trunc('month', r.created_at) as month,
    count(r.request_id) as request_count
from Requests r
group by date_trunc('month', r.created_at)
order by month;

--Среднее время закрытия заявки
select
    avg(r.closed_at - r.created_at) as average_closing_time
from Requests r
where r.closed_at is not null;

--Распределение заявок по приоритетам
select
    p.name as priority_name,
    count(r.request_id) as request_count
from Requests r
join Priorities p
    on r.priority_id = p.priority_id
group by p.name;

--Топ категорий неисправностей
select
    c.name as category_name,
    count(r.request_id) as request_count
from Requests r
join Categories c
    on r.category_id = c.category_id
group by c.name
order by request_count desc;

--Количество активных заявок на каждого исполнителя
select
    e.employee_id,
    u.full_name,
    count(r.request_id) as active_requests
from Employees e
join Users u
    on e.user_id = u.user_id
join Request_Employees re
    on e.employee_id = re.employee_id
join Requests r
    on re.request_id = r.request_id
join Statuses s
    on r.status_id = s.status_id
where s.name <> 'Закрыта'
group by e.employee_id, u.full_name;

--Среднее время выполнения по исполнителю
select
    u.full_name,
    avg(r.closed_at - r.created_at) as average_completion_time
from Employees e
join Users u
    on e.user_id = u.user_id
join Request_Employees re
    on e.employee_id = re.employee_id
join Requests r
    on re.request_id = r.request_id
where r.closed_at is not null
group by u.full_name;

--Все заявки конкретной комнаты
select
    r.request_id,
    r.title,
    r.created_at,
    s.name as status_name
from Requests r
join Statuses s
    on r.status_id = s.status_id
where r.room_id = 1
order by r.created_at;

--Самые проблемные комнаты
select
    rm.room_number,
    count(r.request_id) as request_count
from Rooms rm
left join Requests r
    on rm.room_id = r.room_id
group by rm.room_number
order by request_count desc;

--Жильцы с истекающим сроком проживания(менее 30 дней)
select
    u.full_name,
    rm.room_number,
    rs.contract_end_date
from Residence rs
join Users u
    on rs.user_id = u.user_id
join Rooms rm
    on rs.room_id = rm.room_id
where rs.contract_end_date
    between current_date
    and current_date + interval '30 days'
order by rs.contract_end_date;

--Безопастный запрос
prepare room_requests(integer) as
select
    r.request_id,
    r.title
from Requests r
where r.room_id = $1;

execute room_requests(1);



