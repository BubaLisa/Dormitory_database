create role dorm_user;
create role dorm_employee;
create role dorm_admin;


grant select on Requests to dorm_user;
grant select on Comments to dorm_user;
grant insert on Requests to dorm_user;
grant insert on Comments to dorm_user;

grant select on all tables in schema public to dorm_employee;
grant update on Requests to dorm_employee;
grant insert on Comments to dorm_employee;

grant all privileges on all tables in schema public to dorm_admin;
grant all privileges on all sequences in schema public to dorm_admin;